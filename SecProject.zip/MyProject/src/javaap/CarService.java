package javaap;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CarService {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/CarServiceDB"; // Ensure database name matches
    private static final String DB_USER = "root";  // Replace with your MySQL username
    private static final String DB_PASSWORD = "Ishanya94"; // Replace with your MySQL password

    private Connection conn;

    public CarService() {
        // Connect to the database
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to the database successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    /**
     * @wbp.parser.entryPoint
     */
    public void createGUI() {
        // Create the main frame
        JFrame frame = new JFrame("Car Service System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // Create tabs
        JTabbedPane tabbedPane = new JTabbedPane();

        // Add tabs
        tabbedPane.addTab("View Services", createViewServicesPanel());
        tabbedPane.addTab("Book Service", createBookServicePanel());
        tabbedPane.addTab("View Bookings", createViewBookingsPanel());

        frame.getContentPane().add(tabbedPane);
        frame.setVisible(true);
    }

    // Panel to view services
    private JPanel createViewServicesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTable table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh Services");
        refreshButton.addActionListener(e -> {
            String query = "SELECT * FROM Services";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                DefaultTableModel model = new DefaultTableModel(new String[]{"Service ID", "Service Name", "Price"}, 0);
                while (rs.next()) {
                    model.addRow(new Object[]{rs.getInt("ServiceID"), rs.getString("ServiceName"), rs.getDouble("Price")});
                }
                table.setModel(model);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "Error fetching services: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(refreshButton, BorderLayout.SOUTH);

        return panel;
    }

    // Panel to book services
    private JPanel createBookServicePanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JLabel phoneLabel = new JLabel("Phone:");
        JTextField phoneField = new JTextField();
        JLabel serviceIdLabel = new JLabel("Service ID:");
        JTextField serviceIdField = new JTextField();
        JLabel dateLabel = new JLabel("Booking Date (YYYY-MM-DD):");
        JTextField dateField = new JTextField();

        JButton bookButton = new JButton("Book Service");
        bookButton.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            int serviceId;
            try {
                serviceId = Integer.parseInt(serviceIdField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Invalid Service ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String date = dateField.getText();

            String insertCustomerQuery = "INSERT INTO Customers (Name, Email, Phone) VALUES (?, ?, ?)";
            try (PreparedStatement customerStmt = conn.prepareStatement(insertCustomerQuery, Statement.RETURN_GENERATED_KEYS)) {
                customerStmt.setString(1, name);
                customerStmt.setString(2, email);
                customerStmt.setString(3, phone);
                customerStmt.executeUpdate();

                ResultSet rs = customerStmt.getGeneratedKeys();
                if (rs.next()) {
                    int customerId = rs.getInt(1);

                    String insertBookingQuery = "INSERT INTO Bookings (CustomerID, ServiceID, BookingDate) VALUES (?, ?, ?)";
                    try (PreparedStatement bookingStmt = conn.prepareStatement(insertBookingQuery)) {
                        bookingStmt.setInt(1, customerId);
                        bookingStmt.setInt(2, serviceId);
                        bookingStmt.setDate(3, Date.valueOf(date));
                        bookingStmt.executeUpdate();
                        JOptionPane.showMessageDialog(panel, "Service booked successfully!");
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "Error booking service: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(serviceIdLabel);
        panel.add(serviceIdField);
        panel.add(dateLabel);
        panel.add(dateField);
        panel.add(new JLabel()); // Empty space
        panel.add(bookButton);

        return panel;
    }
    // Panel to view bookings
    private JPanel createViewBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTable table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh Bookings");
        refreshButton.addActionListener(e -> {
            String query = """
                    SELECT b.BookingID, c.Name, s.ServiceName, b.BookingDate, b.Status
                    FROM Bookings b
                    JOIN Customers c ON b.CustomerID = c.CustomerID
                    JOIN Services s ON b.ServiceID = s.ServiceID""";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                DefaultTableModel model = new DefaultTableModel(new String[]{"Booking ID", "Customer", "Service", "Date", "Status"}, 0);
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getInt("BookingID"),
                            rs.getString("Name"),
                            rs.getString("ServiceName"),
                            rs.getDate("BookingDate"),
                            rs.getString("Status")
                    });
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "Error fetching bookings: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(refreshButton, BorderLayout.SOUTH);
        return panel;
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CarServiceGUI app = new CarServiceGUI();
            app.createGUI(); });
    }
}
