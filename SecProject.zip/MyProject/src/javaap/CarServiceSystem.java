package javaap;

import java.sql.*;
import java.util.Scanner;

public class CarServiceSystem {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/CarServiceDB"; // Ensure database name matches
    private static final String DB_USER = "root";  // Replace with your MySQL username
    private static final String DB_PASSWORD = "Ishanya94"; // Replace with your MySQL password

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connected to the database successfully!");
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n=== Car Service System ===");
                System.out.println("1. View Services");
                System.out.println("2. Book Service");
                System.out.println("3. View Bookings");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> viewServices(conn);
                    case 2 -> bookService(conn, scanner);
                    case 3 -> viewBookings(conn);
                    case 4 -> {
                        System.out.println("Exiting the system. Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
        }
    }

    // View all available services
    private static void viewServices(Connection conn) {
        String query = "SELECT * FROM Services";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\nAvailable Services:");
            while (rs.next()) {
                System.out.printf("ID: %d | Service: %s | Price: ₹%.2f\n",
                        rs.getInt("ServiceID"), rs.getString("ServiceName"), rs.getDouble("Price"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching services: " + e.getMessage());
        }
    }

    // Book a car service
    private static void bookService(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter your name: ");
            scanner.nextLine(); // Consume leftover newline
            String name = scanner.nextLine();

            System.out.print("Enter your email: ");
            String email = scanner.nextLine();

            System.out.print("Enter your phone number: ");
            String phone = scanner.nextLine();

            // Insert customer into Customers table
            String insertCustomerQuery = "INSERT INTO Customers (Name, Email, Phone) VALUES (?, ?, ?)";
            try (PreparedStatement customerStmt = conn.prepareStatement(insertCustomerQuery, Statement.RETURN_GENERATED_KEYS)) {
                customerStmt.setString(1, name);
                customerStmt.setString(2, email);
                customerStmt.setString(3, phone);
                customerStmt.executeUpdate();

                // Get the generated CustomerID
                ResultSet rs = customerStmt.getGeneratedKeys();
                if (rs.next()) {
                    int customerId = rs.getInt(1);
                    System.out.println("Customer registered successfully! Your Customer ID: " + customerId);

                    // Display available services
                    viewServices(conn);

                    System.out.print("Enter Service ID to book: ");
                    int serviceId = scanner.nextInt();

                    System.out.print("Enter booking date (YYYY-MM-DD): ");
                    scanner.nextLine(); // Consume leftover newline
                    String bookingDate = scanner.nextLine();

                    // Insert booking into Bookings table
                    String insertBookingQuery = "INSERT INTO Bookings (CustomerID, ServiceID, BookingDate) VALUES (?, ?, ?)";
                    try (PreparedStatement bookingStmt = conn.prepareStatement(insertBookingQuery)) {
                        bookingStmt.setInt(1, customerId);
                        bookingStmt.setInt(2, serviceId);
                        bookingStmt.setDate(3, Date.valueOf(bookingDate));
                        bookingStmt.executeUpdate();
                        System.out.println("Service booked successfully!");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error booking service: " + e.getMessage());
        }
    }

    // View all bookings
    private static void viewBookings(Connection conn) {
        String query = """
                SELECT b.BookingID, c.Name, s.ServiceName, b.BookingDate, b.Status
                FROM Bookings b
                JOIN Customers c ON b.CustomerID = c.CustomerID
                JOIN Services s ON b.ServiceID = s.ServiceID
                """;
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\nAll Bookings:");
            while (rs.next()) {
                System.out.printf("Booking ID: %d | Customer: %s | Service: %s | Date: %s | Status: %s\n",
                        rs.getInt("BookingID"), rs.getString("Name"), rs.getString("ServiceName"),
                        rs.getDate("BookingDate"), rs.getString("Status"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching bookings: " + e.getMessage());
        }
    }
}
