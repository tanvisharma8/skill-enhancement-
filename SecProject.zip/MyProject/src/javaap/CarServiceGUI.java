package javaap;

public class CarServiceGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void createGUI() {
		// TODO Auto-generated method stub
		
	}

}
